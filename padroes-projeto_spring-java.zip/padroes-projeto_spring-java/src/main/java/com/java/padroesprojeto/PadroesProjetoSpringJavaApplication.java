package com.java.padroesprojeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PadroesProjetoSpringJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PadroesProjetoSpringJavaApplication.class, args);
	}

}
